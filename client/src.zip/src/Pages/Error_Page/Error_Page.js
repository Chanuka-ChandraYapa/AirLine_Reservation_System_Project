import React from 'react';

function Error_Page(){
    return (
        <div>
            Error! Page not found
        </div>
    )
}

export default Error_Page;